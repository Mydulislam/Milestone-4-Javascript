function feetToInch(feet){
    const inchValue = feet * 12;
    return inchValue;
}

const result = feetToInch(5);
console.log(result);